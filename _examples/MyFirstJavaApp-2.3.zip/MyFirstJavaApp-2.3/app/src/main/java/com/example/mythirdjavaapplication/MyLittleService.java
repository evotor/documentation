package com.example.mythirdjavaapplication;

import android.content.Intent;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import ru.evotor.framework.core.IntegrationService;
import ru.evotor.framework.core.action.event.receipt.before_positions_edited.BeforePositionsEditedEvent;
import ru.evotor.framework.core.action.event.receipt.before_positions_edited.BeforePositionsEditedEventProcessor;
import ru.evotor.framework.core.action.event.receipt.before_positions_edited.BeforePositionsEditedEventResult;
import ru.evotor.framework.core.action.event.receipt.changes.position.IPositionChange;
import ru.evotor.framework.core.action.event.receipt.changes.position.PositionAdd;
import ru.evotor.framework.core.action.processor.ActionProcessor;
import ru.evotor.framework.receipt.Position;

public class MyLittleService extends IntegrationService {


    @Nullable
    @Override
    protected Map<String, ActionProcessor> createProcessors() {
        Map<String, ActionProcessor> map = new HashMap<>();

        map.put(BeforePositionsEditedEvent.NAME_SELL_RECEIPT, new BeforePositionsEditedEventProcessor() {
            @Override
            public void call(@NonNull String action, @NonNull BeforePositionsEditedEvent beforePositionsEditedEvent, @NonNull Callback callback) {
               boolean hasCoffee = false;
                for (IPositionChange change : beforePositionsEditedEvent.getChanges()) {
                    if (change instanceof PositionAdd) {
                        Position position = ((PositionAdd) change).getPosition();
                        if (position.getName().equals("Кофе")) {
                            hasCoffee = true;
                            break;
                        }
                    }
                }

                try {
                    if (!hasCoffee) {
                        callback.skip();
                    } else {
                        callback.startActivity(new Intent(getApplicationContext(), SugarSuggestionActivity.class));
                    }
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        });

        return map;
    }
}
