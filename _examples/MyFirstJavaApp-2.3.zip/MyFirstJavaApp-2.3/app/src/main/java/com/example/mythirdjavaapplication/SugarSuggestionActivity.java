package com.example.mythirdjavaapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import ru.evotor.framework.core.IntegrationAppCompatActivity;
import ru.evotor.framework.core.action.event.receipt.before_positions_edited.BeforePositionsEditedEventResult;
import ru.evotor.framework.core.action.event.receipt.changes.position.IPositionChange;
import ru.evotor.framework.core.action.event.receipt.changes.position.PositionAdd;
import ru.evotor.framework.receipt.Position;

public class SugarSuggestionActivity extends IntegrationAppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sugar_suggestion);

        findViewById(R.id.buttonYes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<IPositionChange> changes = new ArrayList<>();
                changes.add(new PositionAdd(
                        Position.Builder.newInstance(
                                UUID.randomUUID().toString(),
                                null,
                                "Сахар",
                                "шт",
                                0,
                                new BigDecimal(3),
                                BigDecimal.ONE
                        ).build()
                ));

                setIntegrationResult(new BeforePositionsEditedEventResult(changes, null));
                finish();
            }
        });

        findViewById(R.id.buttonNo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
