package com.example.mythirdjavaapplication;

import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

import ru.evotor.framework.core.IntegrationService;
import ru.evotor.framework.core.action.event.receipt.before_positions_edited.BeforePositionsEditedEvent;
import ru.evotor.framework.core.action.event.receipt.before_positions_edited.BeforePositionsEditedEventProcessor;
import ru.evotor.framework.core.action.processor.ActionProcessor;

public class MyLittleService extends IntegrationService {


    @Nullable
    @Override
    protected Map<String, ActionProcessor> createProcessors() {
        Map<String, ActionProcessor> map = new HashMap<>();

        map.put(BeforePositionsEditedEvent.NAME_SELL_RECEIPT, new BeforePositionsEditedEventProcessor() {
            @Override
            public void call(@NonNull String action, @NonNull BeforePositionsEditedEvent beforePositionsEditedEvent, @NonNull Callback callback) {
                Log.d("MyLittleService", "Handle event: " + action);
                try {
                    callback.skip();
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        });

        return map;
    }
}
